- Product Licenses

An Ocean Developers License is legally required to create Ocean plug-ins. The licensing of the plug-in is the responsibility of the plug-in developer and the Ocean API provides classes to help with the licensing.

An Ocean Developers License provides access to all licensable modules of the Petrel and Studio platforms. When running Petrel using an Ocean Developers License the windows will be watermarked indicating that the Ocean Developers License is in use. If a Petrel project is saved when running under an Ocean Developers License the project will be tainted, with appropriate warning, and will not be able to be opened when running Petrel with a production Petrel license.


- The Language of the Ocean API
The Ocean for Petrel API is an object oriented framework which is built on .NET and which uses C# as its language. It is therefore useful to have an understanding of Object Oriented Design, .NET, and C# when writing plug-ins. Here are some links to help you get started:

.NET
http://msdn.microsoft.com/en-us/netframework/aa663309
C#
http://msdn.microsoft.com/en-us/library/a72418yk.aspx
Object Oriented Design
http://www.oodesign.com/
http://en.wikipedia.org/wiki/Object-oriented_programming

- Petrel Training
Creating Ocean plug-ins for Petrel requires at least a basic understanding of the Petrel application. Through the Software Training Website you can find Petrel classroom training in our training centers worldwide through our Network of Excellence in Training (NExT).

- Ocean Training
Training on the Ocean API is provided by SIS to help you get started with your plug-in development. The Ocean Fundamentals Course is the starting point and provides a broad view of the Ocean API. You may also get refresher information through an online set of Training Videos.
In addition to training courses the Ocean Store provides access to a Getting Started Guide and Webinars on various topics of interest to Ocean Developers. You may also download an Ocean Developers Guide for more detailed information.

- Help and Support
The Ocean Developer Community is a rich and diverse group of software engineers and domain specialists that continues to grow with the popularity of Ocean. As a licensed Ocean Developer you will have access to this resource through the Ocean Store Developers page. Here you can log questions and issues with the Ocean Support team through a Submit/View Ticket page or converse with others in the community through Ocean Developer Forums.
